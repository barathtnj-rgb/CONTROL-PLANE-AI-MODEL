# Official Automated Verification Suite for ControlPlane.ai
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.models import UserQuery, PolicyAction, Review, Venue
from backend.venues_data import get_seed_venues
from backend.recommender import RecommenderEngine
from backend.controlplane import ControlPlane
from backend.responsibility_monitor import ResponsibilityMonitor
from backend.performance_monitor import PerformanceMonitor

def test_nlp_bot_detection():
    print("[TEST 1] Testing NLP Bot & Scripted Review Ring Detection...")
    resp = ResponsibilityMonitor()
    bot_reviews = [
        Review('r1', 'u1', 'Bot1', 5.0, 'The ambience was very good and staff was very polite. Best place in the city for family and friends 10/10 recommended must visit again!', 1, True),
        Review('r2', 'u2', 'Bot2', 5.0, 'The ambience was very good and staff was very polite. Best place in the city for family and friends 10/10 recommended must visit again!', 2, True),
        Review('r3', 'u3', 'Bot3', 5.0, 'The ambience was very good and staff was very polite. Best place in the city for family and friends 10/10 recommended must visit again!', 3, True),
    ]
    prob, count, clusters = resp.analyze_reviews(bot_reviews)
    print(f"  -> Scripted Bot Probability: {prob}% (Suspected Count: {count}, Clusters: {len(clusters)})")
    assert prob >= 70.0, f"Expected bot probability >= 70%, got {prob}%"
    print("  -> PASSED: Bot Syndicate Ring Successfully Intercepted!\n")

def test_freshness_decay():
    print("[TEST 2] Testing Price Staleness Exponential Decay...")
    perf = PerformanceMonitor()
    stale_venue = Venue(
        id='v_test_stale', name='Old Price Bistro', category='Food & Dining', cuisines=['North Indian'],
        area='HITEC City', city='Hyderabad', latitude=17.4482, longitude=78.3742,
        avg_cost_for_two=800, raw_rating=4.5, total_reviews_count=100,
        menu_last_verified_days_ago=210,
        is_currently_open=True, opening_hours='10am-10pm'
    )
    audit = perf.evaluate(stale_venue, UserQuery())
    print(f"  -> 210-Day Staleness Freshness Index: {audit.price_freshness_index}% (Is Stale: {audit.is_price_stale})")
    assert audit.price_freshness_index < 10.0
    assert audit.is_price_stale is True
    print("  -> PASSED: Severe Price Staleness Flagged & Blocked!")

def test_strict_domain_matching():
    print("[TEST 3] Testing Strict Multi-Domain Relevance Matching...")
    venues = get_seed_venues()
    rec = RecommenderEngine(venues)
    
    # Gym Query
    q_gym = UserQuery(search_prompt="gym in HITEC City")
    cands_gym = rec.generate_candidates(q_gym)
    print(f"  -> 'gym in HITEC City' matched: {len(cands_gym)} venues")
    assert len(cands_gym) > 0
    assert all("Services & Wellness" in c.venue.category for c in cands_gym)
    
    # Chinese Query
    q_food = UserQuery(search_prompt="Chinese dimsums in Kondapur")
    cands_food = rec.generate_candidates(q_food)
    print(f"  -> 'Chinese dimsums in Kondapur' matched: {len(cands_food)} venues")
    assert len(cands_food) > 0
    assert all("Food & Dining" in c.venue.category for c in cands_food)
    print("  -> PASSED: Strict Domain Relevance Verified (0 Irrelevant Fallbacks)!\n")

def test_end_to_end_pipeline():
    print("[TEST 4] Testing End-to-End ControlPlane Spatial Governance Pipeline...")
    venues = get_seed_venues()
    rec = RecommenderEngine(venues)
    cp = ControlPlane()
    
    query = UserQuery(category="Any", max_budget=3500.0, user_lat=17.4482, user_lng=78.3742, max_distance_km=10.0, search_prompt="aerobics")
    candidates = rec.generate_candidates(query)
    results = cp.process_recommendations(candidates, query)
    
    verified_count = results['verified_count']
    total_evaluated = results['total_candidates_evaluated']
    print(f"  -> Total Candidates: {total_evaluated} | Verified: {verified_count} | Tokens: {results['total_tokens_consumed']}")
    assert verified_count > 0
    print("  -> PASSED: Full 3-Pillar Governance Pipeline Functioning Perfectly!\n")

if __name__ == '__main__':
    print("================================================================")
    print(">>> RUNNING CONTROLPLANE.AI OFFICIAL VERIFICATION SUITE <<<")
    print("================================================================")
    test_nlp_bot_detection()
    test_freshness_decay()
    test_strict_domain_matching()
    test_end_to_end_pipeline()
    print("================================================================")
    print(">>> SUCCESS: 100% OF ALL 4 TEST SUITES PASSED FOR SUBMISSION! <<<")
    print("================================================================")
