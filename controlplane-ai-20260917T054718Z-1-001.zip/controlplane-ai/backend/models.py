# Models
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from enum import Enum

class BusinessCategory(str, Enum):
    FOOD = "Food & Dining"
    RETAIL = "Fashion & Retail"
    ENTERTAINMENT = "Entertainment & Leisure"
    SERVICES = "Services & Wellness"
    ANY = "Any"

class PolicyAction(str, Enum):
    ALLOW = "ALLOW"
    MODIFY = "MODIFY"
    ESCALATE = "ESCALATE"
    BLOCK = "BLOCK"

class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

@dataclass
class Review:
    id: str
    user_id: str
    user_name: str
    rating: float
    text: str
    timestamp_days_ago: int
    verified_visit: bool = True
    account_review_count: int = 5
    is_suspected_bot: bool = False

@dataclass
class MenuItem:
    name: str
    category: str
    price: float
    is_veg: bool = True
    is_vegan: bool = False
    is_halal: bool = False
    is_gluten_free: bool = False
    allergens: List[str] = field(default_factory=list)

@dataclass
class Venue:
    id: str
    name: str
    category: str # "Food & Dining", "Fashion & Retail", "Entertainment & Leisure", "Services & Wellness"
    cuisines: List[str] # Tags or subcategories (e.g. ['South Indian'], ['Streetwear', 'Sneakers'], ['VR Gaming'])
    area: str
    city: str
    latitude: float
    longitude: float
    avg_cost_for_two: float
    raw_rating: float
    total_reviews_count: int
    menu_last_verified_days_ago: int
    is_currently_open: bool
    opening_hours: str
    is_pure_veg: bool = False
    is_vegan_friendly: bool = False
    is_halal_certified: bool = False
    ambience: str = "Casual"
    noise_level: str = "Moderate"
    is_sponsored: bool = False
    sponsor_boost_weight: float = 0.0
    description: str = ""
    claimed_distance_km: Optional[float] = None
    discount_scam_detected: bool = False
    hidden_fee_risk: bool = False
    menu_items: List[MenuItem] = field(default_factory=list)
    reviews: List[Review] = field(default_factory=list)

@dataclass
class UserQuery:
    category: str = "Any"
    cuisine: str = "Any"
    dietary_preference: str = "None"
    max_budget: float = 1500.0
    user_lat: float = 17.4482
    user_lng: float = 78.3742
    max_distance_km: float = 6.0
    ambience: str = "Any"
    occasion: str = "Casual"
    search_prompt: str = ""

@dataclass
class PerformanceAudit:
    score: float
    risk_score: float
    price_freshness_index: float
    price_staleness_days: int
    is_price_stale: bool
    actual_distance_km: float
    claimed_distance_km: float
    distance_anomaly_detected: bool
    is_open: bool
    hours_status: str
    dietary_compliance_passed: bool
    dietary_violations: List[str] = field(default_factory=list)
    flags: List[str] = field(default_factory=list)

@dataclass
class CostAudit:
    score: float
    risk_score: float
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    estimated_cost_usd: float
    cache_hit: bool
    api_calls_made: int
    latency_ms: float
    cost_saved_usd: float
    flags: List[str] = field(default_factory=list)

@dataclass
class ReviewClusterMatch:
    cluster_phrase: str
    occurrences: int
    matching_review_ids: List[str]
    similarity_score: float

@dataclass
class ResponsibilityAudit:
    score: float
    risk_score: float
    scripted_review_probability: float
    suspected_fake_reviews_count: int
    total_reviews_analyzed: int
    repetition_clusters: List[ReviewClusterMatch] = field(default_factory=list)
    raw_rating: float = 0.0
    authenticity_adjusted_rating: float = 0.0
    sponsored_bias_detected: bool = False
    sponsored_penalty_applied: float = 0.0
    discount_scam_detected: bool = False
    hidden_fees_detected: bool = False
    privacy_safe: bool = True
    hallucination_detected: bool = False
    flags: List[str] = field(default_factory=list)

@dataclass
class ControlPlaneAudit:
    venue_id: str
    venue_name: str
    category: str
    overall_risk_score: float
    overall_trust_score: float
    risk_level: RiskLevel
    policy_action: PolicyAction
    performance_audit: PerformanceAudit
    cost_audit: CostAudit
    responsibility_audit: ResponsibilityAudit
    reasons: List[str] = field(default_factory=list)
    disclaimers: List[str] = field(default_factory=list)
    suggested_alternatives: List[str] = field(default_factory=list)
    execution_time_ms: float = 0.0

@dataclass
class RecommendationCandidate:
    venue: Venue
    ai_raw_match_score: float
    ai_raw_reason: str
