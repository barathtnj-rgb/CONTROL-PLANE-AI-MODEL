# Universal Spatial Recommender Engine with Exhaustive Multi-Domain Ontology
import math
from typing import List
from .models import UserQuery, Venue, RecommendationCandidate
from .venues_data import get_seed_venues

def fast_dist(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    dlat = (lat2 - lat1) * 111.0
    dlon = (lon2 - lon1) * 95.0
    return round(math.sqrt(dlat * dlat + dlon * dlon), 2)

# Exhaustive Multi-Domain Taxonomy
CATEGORY_INTENTS = {
    "Services & Wellness": [
        # Fitness, Aerobics & Sports
        "gym", "fitness", "aerobic", "aerobics", "zumba", "dance", "boxing", "crossfit", "yoga", 
        "pilates", "swimming", "swim", "pool", "badminton", "tennis", "squash", "calisthenics", 
        "spinning", "cycling", "cycle", "weight loss", "physiotherapy", "physio", "trainer", 
        "powerlifting", "mma", "martial arts", "karate", "judo", "taekwondo", "kickboxing", "workout",
        # Spa, Salons & Grooming
        "spa", "salon", "haircut", "hair", "styling", "barber", "massage", "ayurveda", "ayurvedic",
        "facial", "manicure", "pedicure", "keratin", "beard", "tattoo", "tattoos", "skin", "skin care",
        "sauna", "steam", "wellness", "dermatology", "nails", "nail art",
        # Essentials & Health
        "clinic", "dentist", "dental", "opticals", "optician", "glasses", "pharmacy", "medical",
        "pet care", "pet", "vet", "veterinary", "dog", "laundry", "dry clean", "car wash", "auto repair", "tailor"
    ],
    "Food & Dining": [
        # Global Cuisines
        "chinese", "asian", "pan-asian", "noodles", "dimsums", "dimsum", "sushi", "ramen", "momo", "momos",
        "thai", "japanese", "korean", "italian", "pizza", "pasta", "mexican", "tacos", "burrito",
        "continental", "american", "burger", "burgers", "sandwich", "sandwiches", "shawarma", "arabic", "mandi",
        # Indian Cuisines
        "biryani", "dum biryani", "hyderabadi", "mutton", "chicken", "kebab", "kebabs", "tandoori", "bbq", "barbeque", "buffet",
        "north indian", "south indian", "tiffin", "tiffins", "dosa", "idli", "vada", "puri", "thali", "sattvic",
        "pure veg", "veg", "vegetarian", "vegan", "halal", "seafood", "fish", "prawns", "paneer", "curry", "dal",
        # Cafes, Bakeries & Bars
        "coffee", "cafe", "espresso", "latte", "tea", "chai", "bakery", "pastry", "pastries", "cake", "cakes",
        "dessert", "desserts", "ice cream", "gelato", "waffle", "waffles", "pancake", "smoothie", "juice",
        "rooftop", "brewery", "bar", "pub", "cocktail", "cocktails", "lounge", "dine", "dining", "restaurant", "food"
    ],
    "Fashion & Retail": [
        # Footwear & Streetwear
        "sneaker", "sneakers", "shoes", "shoe", "kicks", "jordans", "boots", "sandals", "heels", "footwear",
        "streetwear", "oversized", "hoodie", "hoodies", "t-shirt", "t-shirts", "tees", "denim", "jeans", "jacket", "jackets",
        # Apparel & Luxury Couture
        "clothing", "clothes", "dress", "dresses", "shirt", "shirts", "suit", "suits", "blazer", "blazers", "tuxedo",
        "formal", "casual", "activewear", "sportswear", "ethnic", "saree", "sarees", "kurta", "kurtas", "lehenga",
        "bridal", "wedding", "sherwani", "handloom", "linen", "silk", "cotton", "boutique", "fashion", "shopping", "retail", "wear",
        # Accessories & Lifestyle
        "watch", "watches", "jewelry", "jewellery", "gold", "diamond", "diamonds", "silver", "sunglasses", "shades",
        "bag", "bags", "handbag", "handbags", "backpack", "luggage", "perfume", "fragrance", "cosmetics", "makeup",
        "book", "books", "stationery", "electronics", "gadgets", "mobile", "laptop", "sports gear"
    ],
    "Entertainment & Leisure": [
        # Games & Physical Leisure
        "bowling", "go-karting", "gokart", "karting", "racing", "arcade", "gaming", "game", "games", "vr", "virtual reality",
        "ps5", "playstation", "esports", "snooker", "pool", "billiards", "laser tag", "paintball", "trampoline",
        "escape room", "mystery rooms", "turf", "cricket", "football", "sports",
        # Entertainment & Arts
        "movie", "movies", "cinema", "imax", "4dx", "theatre", "drive-in", "amusement", "water park", "resort",
        "zoo", "museum", "art", "comedy", "standup", "live music", "karaoke", "club", "clubbing", "party"
    ]
}

LOCATION_KEYWORDS = [
    "hitec", "gachibowli", "jubilee", "banjara", "kondapur", "madhapur",
    "kukatpally", "secunderabad", "begumpet", "charminar", "dilsukhnagar",
    "financial", "manikonda", "ameerpet", "kompally", "shamshabad", "iit", "kandi",
    "miyapur", "alwal", "malkajgiri", "uppal", "tarnaka", "mehdipatnam", "lb nagar"
]

class RecommenderEngine:
    def __init__(self, venues=None):
        self.venues = venues if venues is not None else get_seed_venues()

    def generate_candidates(self, query: UserQuery):
        return self.get_candidates(query)

    def get_candidates(self, query: UserQuery) -> List[RecommendationCandidate]:
        all_venues = self.venues or get_seed_venues()
        candidates = []

        prompt_lower = (query.search_prompt or "").lower().strip()
        
        # 1. Broad Multi-Domain Category Detection
        detected_category = None
        for cat, keywords in CATEGORY_INTENTS.items():
            if any(k in prompt_lower for k in keywords):
                detected_category = cat
                break

        # 2. Location Keyword Extraction
        matched_location = None
        for loc in LOCATION_KEYWORDS:
            if loc in prompt_lower:
                matched_location = loc
                break

        target_cat = query.category if query.category != "Any" else detected_category
        clean_prompt = prompt_lower
        if matched_location:
            clean_prompt = clean_prompt.replace(matched_location, "").strip()
        
        tokens = [t for t in clean_prompt.split() if len(t) > 2] if clean_prompt else []

        max_radius = query.max_distance_km
        lat_u = query.user_lat
        lng_u = query.user_lng

        for venue in all_venues:
            # Category Filtering
            if target_cat and venue.category != target_cat:
                continue

            # Location Filtering
            if matched_location:
                venue_text = f"{venue.name} {venue.area} {venue.city}".lower()
                if matched_location not in venue_text:
                    continue

            # Intent Keyword Fuzzy/Stemmed Matching
            if tokens:
                venue_searchable = f"{venue.name} {venue.category} {' '.join(venue.cuisines)} {venue.description}".lower()
                # Matches if any token is a substring of the searchable venue text
                if not any(t in venue_searchable for t in tokens):
                    continue

            # Budget Filtering
            if query.max_budget and venue.avg_cost_for_two > query.max_budget:
                continue

            # Spatial Distance Filtering
            dist = fast_dist(lat_u, lng_u, venue.latitude, venue.longitude)
            if dist > max_radius:
                continue

            # Relevance Scoring
            raw_match = 80.0 + (venue.raw_rating * 3.0) - (dist * 1.5)
            candidates.append(RecommendationCandidate(
                venue=venue,
                ai_raw_match_score=round(min(99.0, max(50.0, raw_match)), 1),
                ai_raw_reason=f"Matches {venue.category} ({venue.cuisines[0] if venue.cuisines else 'Verified'}) in {venue.area} ({dist} km away)."
            ))

            if len(candidates) >= 25:
                break

        candidates.sort(key=lambda x: x.ai_raw_match_score, reverse=True)
        return candidates
