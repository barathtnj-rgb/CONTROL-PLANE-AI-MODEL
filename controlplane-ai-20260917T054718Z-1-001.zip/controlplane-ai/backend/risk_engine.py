# Risk Scoring and Policy Intervention Engine
from typing import List, Tuple
from .models import (
    Venue, UserQuery, PerformanceAudit, CostAudit, 
    ResponsibilityAudit, ControlPlaneAudit, RiskLevel, PolicyAction
)

class RiskEngine:
    W_PERF = 0.40
    W_COST = 0.20
    W_RESP = 0.40

    def evaluate(
        self,
        venue: Venue,
        perf: PerformanceAudit,
        cost: CostAudit,
        resp: ResponsibilityAudit,
        execution_time_ms: float = 0.0
    ) -> ControlPlaneAudit:
        reasons = []
        disclaimers = []
        suggested_alts = []

        # 1. Compute Composite Risk Score (0-100)
        overall_risk = (
            (self.W_PERF * perf.risk_score) +
            (self.W_COST * cost.risk_score) +
            (self.W_RESP * resp.risk_score)
        )
        overall_risk = round(min(100.0, max(0.0, overall_risk)), 1)
        trust_score = round(100.0 - overall_risk, 1)

        # 2. Determine Risk Level
        if overall_risk < 25.0:
            risk_level = RiskLevel.LOW
        elif overall_risk < 60.0:
            risk_level = RiskLevel.MEDIUM
        elif overall_risk < 80.0:
            risk_level = RiskLevel.HIGH
        else:
            risk_level = RiskLevel.CRITICAL

        # 3. Policy Action Determination & Interventions
        # Critical Safety Overrides
        if not perf.dietary_compliance_passed:
            action = PolicyAction.BLOCK
            reasons.append('BLOCK: Strict dietary violation detected. Safety risk to user.')
            disclaimers.append('Suppressed: Menu ingredients violate your stated dietary requirements.')
        elif perf.price_staleness_days >= 210:
            action = PolicyAction.BLOCK
            reasons.append(f'BLOCK: Severe data staleness ({perf.price_staleness_days} days old / ~{perf.price_staleness_days//30} months). Prices and menu are unreliable.')
            disclaimers.append('Suppressed: Restaurant has not verified pricing for over 7 months.')
        elif not perf.is_open and overall_risk >= 65.0:
            action = PolicyAction.BLOCK
            reasons.append('BLOCK: Venue is currently closed and failed validation criteria.')
        elif overall_risk >= 80.0:
            action = PolicyAction.BLOCK
            reasons.append('BLOCK: Overall risk exceeds safety threshold (Critical Risk).')
        elif overall_risk >= 60.0 or resp.scripted_review_probability >= 75.0 or not perf.is_open:
            action = PolicyAction.ESCALATE
            reasons.append('ESCALATE: High risk detected. Presenting warning flag and alternative verified venues.')
            if resp.scripted_review_probability >= 75.0:
                disclaimers.append(f'Caution: {resp.scripted_review_probability}% of reviews match bot/scripted pattern rings.')
            if not perf.is_open:
                disclaimers.append('Notice: Venue is closed right now. Consider scheduling for later or choosing an open alternative.')
        elif overall_risk >= 25.0 or perf.is_price_stale or resp.scripted_review_probability >= 30.0 or resp.sponsored_bias_detected:
            action = PolicyAction.MODIFY
            reasons.append('MODIFY: Moderate risk. Displayed with verified corrections and transparency disclosures.')
            if perf.is_price_stale:
                disclaimers.append(f'Price Notice: Menu last verified {perf.price_staleness_days} days ago. Actual bill may vary slightly.')
            if resp.scripted_review_probability >= 30.0:
                disclaimers.append(f'Review Quality: Platform rating {resp.raw_rating}★ adjusted to {resp.authenticity_adjusted_rating}★ due to patterned reviews.')
            if resp.sponsored_bias_detected:
                disclaimers.append('Transparency: Paid sponsorship ranking boost removed for unbiased selection.')
        else:
            action = PolicyAction.ALLOW
            reasons.append('ALLOW: Verified by ControlPlane. High confidence, fresh data, and authentic ratings.')
            disclaimers.append('ControlPlane Verified: 100% authentic data, fresh pricing, open now.')

        # Collect all active flags
        all_flags = perf.flags + cost.flags + resp.flags

        return ControlPlaneAudit(
            venue_id=venue.id,
            venue_name=venue.name,
            category=venue.category,
            overall_risk_score=overall_risk,
            overall_trust_score=trust_score,
            risk_level=risk_level,
            policy_action=action,
            performance_audit=perf,
            cost_audit=cost,
            responsibility_audit=resp,
            reasons=reasons,
            disclaimers=disclaimers,
            suggested_alternatives=suggested_alts,
            execution_time_ms=execution_time_ms
        )
