# Performance Monitor
import math
from typing import List, Tuple
from .models import Venue, UserQuery, PerformanceAudit

class PerformanceMonitor:
    @staticmethod
    def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        R = 6371.0 # Earth radius in kilometers
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat / 2) ** 2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dlon / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return round(R * c, 2)

    def evaluate(self, venue: Venue, query: UserQuery) -> PerformanceAudit:
        flags = []
        violations = []
        
        # 1. Geo-Proximity Verification
        actual_dist = self.haversine_distance(query.user_lat, query.user_lng, venue.latitude, venue.longitude)
        claimed_dist = venue.claimed_distance_km if venue.claimed_distance_km is not None else actual_dist
        
        dist_diff = abs(actual_dist - claimed_dist)
        dist_anomaly = dist_diff > 1.5 # If discrepancy is over 1.5km
        if dist_anomaly:
            flags.append(f'Distance Anomaly: Claimed {claimed_dist}km vs Actual {actual_dist}km')
        
        if actual_dist > query.max_distance_km:
            flags.append(f'Exceeds radius limit ({actual_dist}km > {query.max_distance_km}km)')

        # 2. Price & Menu Staleness Decay Analysis
        # F(t) = 100 * exp(-0.015 * t)
        days = venue.menu_last_verified_days_ago
        freshness_index = round(100.0 * math.exp(-0.015 * days), 1)
        is_stale = days > 90 # Over 3 months is stale, over 6 months is severe
        if days >= 180:
            flags.append(f'Menu data severely outdated ({days} days old / ~{days//30} months ago)')
        elif is_stale:
            flags.append(f'Menu data unverified for {days} days')

        # 3. Operating Hours & Live Status
        is_open = venue.is_currently_open
        hours_status = 'Open Now' if is_open else 'Currently Closed'
        if not is_open:
            flags.append('Venue is currently closed for service')

        # 4. Strict Dietary Verification
        dietary_ok = True
        pref = query.dietary_preference.lower()
        if 'pure veg' in pref or 'vegetarian' in pref:
            if not venue.is_pure_veg:
                # Check if there is high contamination risk
                non_veg_items = [item.name for item in venue.menu_items if not item.is_veg]
                if non_veg_items:
                    dietary_ok = False
                    violations.append(f'Pure Veg requested, but kitchen serves non-veg ({len(non_veg_items)} meat items)')
        elif 'vegan' in pref:
            if not venue.is_vegan_friendly:
                dietary_ok = False
                violations.append('Vegan requested, but venue lacks certified vegan preparation')
        elif 'halal' in pref:
            if not venue.is_halal_certified:
                dietary_ok = False
                violations.append('Halal requested, but venue is not Halal certified')

        # 5. Calculate Pillar Performance & Risk Score (0-100)
        perf_score = 100.0
        risk_score = 0.0

        # Freshness deduction
        freshness_penalty = (100.0 - freshness_index) * 0.4
        risk_score += freshness_penalty

        # Closed penalty
        if not is_open:
            risk_score += 45.0
        
        # Dietary violation penalty (Severe safety risk)
        if not dietary_ok:
            risk_score += 55.0
            
        # Distance anomaly penalty
        if dist_anomaly:
            risk_score += 20.0
        if actual_dist > query.max_distance_km:
            risk_score += 15.0

        risk_score = min(100.0, max(0.0, risk_score))
        perf_score = round(100.0 - risk_score, 1)

        return PerformanceAudit(
            score=perf_score,
            risk_score=round(risk_score, 1),
            price_freshness_index=freshness_index,
            price_staleness_days=days,
            is_price_stale=is_stale,
            actual_distance_km=actual_dist,
            claimed_distance_km=claimed_dist,
            distance_anomaly_detected=dist_anomaly,
            is_open=is_open,
            hours_status=hours_status,
            dietary_compliance_passed=dietary_ok,
            dietary_violations=violations,
            flags=flags
        )
