# High-Performance Cached SQLite Repository
import os
import sqlite3
import math
from typing import List, Optional
from .models import Venue, MenuItem, Review

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'database.sqlite')

_CACHED_VENUES: Optional[List[Venue]] = None

def get_seed_venues() -> List[Venue]:
    global _CACHED_VENUES
    if _CACHED_VENUES is not None:
        return _CACHED_VENUES

    if not os.path.exists(DB_PATH):
        return []

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # Fast 1-Pass Fetch of all venues
    cur.execute("SELECT * FROM venues")
    rows = cur.fetchall()

    venues = []
    for r in rows:
        cuisines_list = [c.strip() for c in r['cuisines'].split(',')]

        # Default sample menu item if food
        menu_items = []
        if r['category'] == 'Food & Dining':
            if r['is_pure_veg']:
                menu_items.append(MenuItem('Special Paneer Thali', 'Mains', 280, True, False, False, False))
            else:
                menu_items.append(MenuItem('Special Dum Biryani', 'Mains', 380, False, False, True, False))

        venues.append(Venue(
            id=r['id'],
            name=r['name'],
            category=r['category'],
            cuisines=cuisines_list,
            area=r['area'],
            city=r['city'],
            latitude=float(r['latitude']),
            longitude=float(r['longitude']),
            avg_cost_for_two=float(r['avg_cost_for_two']),
            raw_rating=float(r['raw_rating']),
            total_reviews_count=int(r['total_reviews_count']),
            menu_last_verified_days_ago=int(r['menu_last_verified_days_ago']),
            is_currently_open=bool(r['is_currently_open']),
            opening_hours=r['opening_hours'],
            is_pure_veg=bool(r['is_pure_veg']),
            is_vegan_friendly=bool(r['is_vegan_friendly']),
            is_halal_certified=bool(r['is_halal_certified']),
            ambience=r['ambience'],
            is_sponsored=bool(r['is_sponsored']),
            sponsor_boost_weight=float(r['sponsor_boost_weight']),
            claimed_distance_km=float(r['claimed_distance_km']) if r['claimed_distance_km'] else None,
            discount_scam_detected=bool(r['discount_scam_detected']),
            hidden_fee_risk=bool(r['hidden_fee_risk']),
            description=r['description'],
            menu_items=menu_items,
            reviews=[]
        ))

    conn.close()
    _CACHED_VENUES = venues
    return _CACHED_VENUES

def invalidate_venues_cache():
    global _CACHED_VENUES
    _CACHED_VENUES = None
