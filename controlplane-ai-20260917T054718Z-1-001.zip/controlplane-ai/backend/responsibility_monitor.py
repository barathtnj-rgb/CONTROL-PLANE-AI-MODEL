# Responsibility Monitor
import re
from typing import List, Dict, Set, Tuple
from collections import Counter
from .models import Venue, UserQuery, Review, ReviewClusterMatch, ResponsibilityAudit

class ResponsibilityMonitor:
    @staticmethod
    def clean_text(text: str) -> str:
        return re.sub(r'[^a-zA-Z0-9\s]', '', text.lower()).strip()

    @staticmethod
    def get_ngrams(text: str, n: int = 4) -> List[str]:
        words = text.split()
        if len(words) < n:
            return [' '.join(words)] if words else []
        return [' '.join(words[i:i+n]) for i in range(len(words) - n + 1)]

    @staticmethod
    def jaccard_similarity(text1: str, text2: str) -> float:
        set1 = set(text1.lower().split())
        set2 = set(text2.lower().split())
        if not set1 or not set2:
            return 0.0
        intersection = len(set1.intersection(set2))
        union = len(set1.union(set2))
        return intersection / union if union > 0 else 0.0

    def analyze_reviews(self, reviews: List[Review]) -> Tuple[float, int, List[ReviewClusterMatch]]:
        if not reviews:
            return 0.0, 0, []

        total_reviews = len(reviews)
        ngram_counter = Counter()
        cleaned_reviews = [self.clean_text(r.text) for r in reviews]
        
        for cr in cleaned_reviews:
            ngs = self.get_ngrams(cr, n=4)
            for ng in set(ngs):
                if len(ng.split()) >= 3 and len(ng) > 12:
                    ngram_counter[ng] += 1

        clusters: List[ReviewClusterMatch] = []
        flagged_review_indices = set()

        for phrase, count in ngram_counter.most_common(5):
            if count >= 2:
                matching_ids = []
                for idx, r in enumerate(reviews):
                    if phrase in cleaned_reviews[idx]:
                        matching_ids.append(r.id)
                        flagged_review_indices.add(idx)
                
                sim_score = min(1.0, 0.5 + (count * 0.15))
                clusters.append(ReviewClusterMatch(
                    cluster_phrase=phrase,
                    occurrences=count,
                    matching_review_ids=matching_ids,
                    similarity_score=round(sim_score, 2)
                ))

        for i in range(total_reviews):
            for j in range(i + 1, total_reviews):
                sim = self.jaccard_similarity(reviews[i].text, reviews[j].text)
                if sim >= 0.65:
                    flagged_review_indices.add(i)
                    flagged_review_indices.add(j)

        for idx, r in enumerate(reviews):
            if r.is_suspected_bot or (not r.verified_visit and r.account_review_count <= 1):
                flagged_review_indices.add(idx)

        suspected_count = len(flagged_review_indices)
        scripted_prob = (suspected_count / total_reviews) * 100.0 if total_reviews > 0 else 0.0

        if clusters and clusters[0].occurrences >= 3:
            scripted_prob = max(scripted_prob, 75.0)

        return round(min(100.0, scripted_prob), 1), suspected_count, clusters

    def evaluate(self, venue: Venue, query: UserQuery) -> ResponsibilityAudit:
        flags = []
        reviews = venue.reviews
        total_rev = len(reviews)
        
        scripted_prob, suspected_count, clusters = self.analyze_reviews(reviews)
        
        raw_rating = venue.raw_rating
        penalty_factor = (scripted_prob / 100.0) * 0.45
        adjusted_rating = round(raw_rating * (1.0 - penalty_factor), 1)

        if scripted_prob >= 50.0:
            flags.append(f'High Scripted Review Risk ({scripted_prob}%): {suspected_count}/{total_rev} reviews show template duplication')
        elif scripted_prob >= 20.0:
            flags.append(f'Moderate review anomaly detected ({suspected_count} patterned reviews)')

        sponsored_bias = venue.is_sponsored
        sponsor_penalty = 0.0
        if sponsored_bias:
            sponsor_penalty = venue.sponsor_boost_weight
            flags.append('Sponsored listing detected: Commercial ranking boost neutralized')

        risk_score = 0.0
        risk_score += scripted_prob * 0.75
        if sponsored_bias:
            risk_score += 15.0

        risk_score = min(100.0, max(0.0, risk_score))
        resp_score = round(100.0 - risk_score, 1)

        return ResponsibilityAudit(
            score=resp_score,
            risk_score=round(risk_score, 1),
            scripted_review_probability=scripted_prob,
            suspected_fake_reviews_count=suspected_count,
            total_reviews_analyzed=total_rev,
            repetition_clusters=clusters,
            raw_rating=raw_rating,
            authenticity_adjusted_rating=adjusted_rating,
            sponsored_bias_detected=sponsored_bias,
            sponsored_penalty_applied=round(sponsor_penalty, 2),
            privacy_safe=True,
            hallucination_detected=False,
            flags=flags
        )
