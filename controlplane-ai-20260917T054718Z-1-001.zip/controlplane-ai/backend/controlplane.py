# Master ControlPlane Orchestrator
import time
from typing import List, Dict, Any
from dataclasses import asdict
from .models import (
    Venue, UserQuery, RecommendationCandidate, ControlPlaneAudit, 
    PolicyAction, RiskLevel
)
from .performance_monitor import PerformanceMonitor
from .cost_optimizer import CostOptimizer
from .responsibility_monitor import ResponsibilityMonitor
from .risk_engine import RiskEngine

class ControlPlane:
    def __init__(self):
        self.perf_monitor = PerformanceMonitor()
        self.cost_optimizer = CostOptimizer()
        self.resp_monitor = ResponsibilityMonitor()
        self.risk_engine = RiskEngine()
        
        # Telemetry History
        self.audit_history: List[Dict[str, Any]] = []

    def audit_candidate(self, candidate: RecommendationCandidate, query: UserQuery) -> ControlPlaneAudit:
        t0 = time.perf_counter()
        venue = candidate.venue

        # 1. Pillar 1: Performance Audit
        perf_audit = self.perf_monitor.evaluate(venue, query)

        # 2. Pillar 2: Cost & Cache Audit
        cost_audit = self.cost_optimizer.evaluate(venue, query)

        # 3. Pillar 3: Responsibility & NLP Scripted Review Audit
        resp_audit = self.resp_monitor.evaluate(venue, query)

        # 4. Master Risk Scoring & Policy Dispatcher
        total_time_ms = round((time.perf_counter() - t0) * 1000 + cost_audit.latency_ms, 2)
        audit_result = self.risk_engine.evaluate(
            venue=venue,
            perf=perf_audit,
            cost=cost_audit,
            resp=resp_audit,
            execution_time_ms=total_time_ms
        )

        return audit_result

    def process_recommendations(self, candidates: List[RecommendationCandidate], query: UserQuery) -> Dict[str, Any]:
        verified_results = []
        blocked_results = []
        total_tokens = 0
        total_cost_saved = 0.0
        total_api_calls = 0

        for cand in candidates:
            audit = self.audit_candidate(cand, query)
            
            # Confidence calibration: Blend raw AI score with ControlPlane Trust
            # Final Confidence = 0.40 * AI_Raw + 0.60 * TrustScore
            calibrated_confidence = round(
                (0.40 * cand.ai_raw_match_score) + (0.60 * audit.overall_trust_score), 1
            )
            
            total_tokens += audit.cost_audit.total_tokens
            total_cost_saved += audit.cost_audit.cost_saved_usd
            total_api_calls += audit.cost_audit.api_calls_made

            # Display badge formatting
            if audit.policy_action == PolicyAction.ALLOW:
                badge = 'ControlPlane: PASSED (Verified Trust)'
            elif audit.policy_action == PolicyAction.MODIFY:
                badge = 'ControlPlane: MODIFIED (Caution Flags Active)'
            elif audit.policy_action == PolicyAction.ESCALATE:
                badge = 'ControlPlane: ESCALATED (High Risk Alert)'
            else:
                badge = 'ControlPlane: BLOCKED (Critical Risk Intercepted)'

            item = {
                'venue': asdict(cand.venue),
                'ai_raw_match_score': cand.ai_raw_match_score,
                'ai_raw_reason': cand.ai_raw_reason,
                'final_confidence_score': calibrated_confidence,
                'controlplane_audit': asdict(audit),
                'is_blocked': audit.policy_action == PolicyAction.BLOCK,
                'display_badge': badge
            }

            if audit.policy_action == PolicyAction.BLOCK:
                blocked_results.append(item)
            else:
                verified_results.append(item)

        # Sort verified results by final calibrated confidence
        verified_results.sort(key=lambda x: x['final_confidence_score'], reverse=True)

        summary = {
            'total_candidates_evaluated': len(candidates),
            'verified_count': len(verified_results),
            'blocked_count': len(blocked_results),
            'total_tokens_consumed': total_tokens,
            'total_cost_saved_usd': round(total_cost_saved, 6),
            'total_api_calls': total_api_calls,
            'verified_recommendations': verified_results,
            'blocked_recommendations': blocked_results
        }

        self.audit_history.append(summary)
        return summary
