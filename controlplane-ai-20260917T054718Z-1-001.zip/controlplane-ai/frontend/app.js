// ControlPlane.ai ? Spatial AI Governance Client Controller
let map = null;
let userMarker = null;
let geofenceCircle = null;
let venueMarkers = {};
let currentRecommendations = [];
let selectedCategory = 'Any';
let currentAuditViewMode = 'governed';

// Hyderabad Coordinates
const LOCATION_COORDINATES = {
  hitec: { name: 'HITEC City (Cyber Towers)', lat: 17.4482, lng: 78.3742 },
  iith: { name: 'IIT Hyderabad (Kandi Campus)', lat: 17.5947, lng: 78.1230 },
  jubilee: { name: 'Jubilee Hills (Road 36)', lat: 17.4320, lng: 78.4080 },
  gachibowli: { name: 'Gachibowli (DLF Cybercity)', lat: 17.4415, lng: 78.3590 },
  kondapur: { name: 'Kondapur (Botanical Garden)', lat: 17.4620, lng: 78.3610 },
  secunderabad: { name: 'Secunderabad (Clock Tower)', lat: 17.4399, lng: 78.4983 }
};

let currentUserLoc = LOCATION_COORDINATES.hitec;
let currentRadiusKm = 6.0;

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) lucide.createIcons();
  initMap();
  handleSearch();
});

// Initialize Leaflet Map
function initMap() {
  const mapElement = document.getElementById('map');
  if (!mapElement) return;

  try {
    map = L.map('map', {
      zoomControl: false,
      attributionControl: false
    }).setView([currentUserLoc.lat, currentUserLoc.lng], 13);

    // Pleasant CartoDB Voyager / OSM Tiles (Vivid, clean, easy to read)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      subdomains: 'abcd'
    }).addTo(map);

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    setTimeout(() => {
      if (map) map.invalidateSize();
    }, 300);

    updateUserMarkerAndGeofence();
  } catch (err) {
    console.error('Leaflet initialization error:', err);
  }
}

function updateUserMarkerAndGeofence() {
  if (!map) return;

  try {
    if (userMarker) map.removeLayer(userMarker);
    if (geofenceCircle) map.removeLayer(geofenceCircle);

    const userIcon = L.divIcon({
      className: 'custom-pin pin-user',
      html: '<i data-lucide="crosshair" class="w-4 h-4 text-white"></i>',
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });

    userMarker = L.marker([currentUserLoc.lat, currentUserLoc.lng], { icon: userIcon })
      .addTo(map)
      .bindPopup(`<strong>Origin Location</strong><br>${currentUserLoc.name}`);

    geofenceCircle = L.circle([currentUserLoc.lat, currentUserLoc.lng], {
      radius: currentRadiusKm * 1000,
      color: '#3B82F6',
      weight: 2,
      opacity: 0.9,
      fillColor: '#3B82F6',
      fillOpacity: 0.12
    }).addTo(map);

    map.flyTo([currentUserLoc.lat, currentUserLoc.lng], calculateZoom(currentRadiusKm), {
      duration: 1.0
    });

    if (window.lucide) lucide.createIcons();
  } catch (e) {
    console.error('Error updating marker:', e);
  }
}

function calculateZoom(radiusKm) {
  if (radiusKm <= 2) return 14;
  if (radiusKm <= 6) return 13;
  if (radiusKm <= 12) return 12;
  return 11;
}

function handleLocationChange(locKey) {
  if (locKey === 'gps') {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          currentUserLoc = {
            name: 'Live Device GPS',
            lat: pos.coords.latitude,
            lng: pos.coords.longitude
          };
          updateUserMarkerAndGeofence();
          handleSearch();
        },
        () => {
          alert('GPS permission unavailable. Defaulting to HITEC City.');
        }
      );
    }
  } else if (LOCATION_COORDINATES[locKey]) {
    currentUserLoc = LOCATION_COORDINATES[locKey];
    updateUserMarkerAndGeofence();
    handleSearch();
  }
}

function handleRadiusSlider(val) {
  currentRadiusKm = parseFloat(val);
  document.getElementById('radius-label').innerText = `${currentRadiusKm.toFixed(1)} km`;
  if (geofenceCircle) {
    geofenceCircle.setRadius(currentRadiusKm * 1000);
  }
}

function togglePillarDrawer() {
  const drawer = document.getElementById('pillar-controls-drawer');
  if (drawer) {
    drawer.classList.toggle('hidden');
  }
  if (window.lucide) lucide.createIcons();
}

function setCategoryFilter(category, btn) {
  selectedCategory = category;
  document.querySelectorAll('.category-chip').forEach(el => {
    el.classList.remove('active', 'bg-indigo-600', 'text-white');
    el.classList.add('bg-[#0F172A]', 'text-slate-300', 'border-slate-700');
  });
  btn.classList.remove('bg-[#0F172A]', 'text-slate-300', 'border-slate-700');
  btn.classList.add('active', 'bg-indigo-600', 'text-white');

  handleSearch();
}

function setAuditViewMode(mode) {
  currentAuditViewMode = mode;
  const btnGov = document.getElementById('btn-mode-governed');
  const btnRaw = document.getElementById('btn-mode-raw');

  if (mode === 'governed') {
    btnGov.className = 'px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-600 text-white';
    btnRaw.className = 'px-2 py-0.5 rounded text-[10px] font-medium text-slate-400';
  } else {
    btnRaw.className = 'px-2 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white';
    btnGov.className = 'px-2 py-0.5 rounded text-[10px] font-medium text-slate-400';
  }

  renderResults(currentRecommendations);
}

async function handleSearch(e) {
  if (e) e.preventDefault();
  const search_prompt = document.getElementById('filter-prompt').value;
  const max_budget = parseFloat(document.getElementById('filter-budget').value || 3500);
  const min_trust = parseFloat(document.getElementById('filter-min-trust').value || 65);
  const max_staleness = parseInt(document.getElementById('filter-max-staleness').value || 180);

  const container = document.getElementById('recommendations-container');
  container.innerHTML = `
    <div class="py-16 flex flex-col items-center justify-center space-y-2 text-slate-400">
      <div class="animate-spin rounded-full h-7 w-7 border-2 border-indigo-500 border-t-transparent"></div>
      <p class="text-[11px] font-mono">ControlPlane auditing 10,000+ candidates in real time...</p>
    </div>
  `;

  try {
    const res = await fetch('/api/recommend', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        category: selectedCategory,
        max_budget: max_budget,
        user_lat: currentUserLoc.lat,
        user_lng: currentUserLoc.lng,
        max_distance_km: currentRadiusKm,
        search_prompt: search_prompt
      })
    });
    const data = await res.json();
    currentRecommendations = data.verified_recommendations || [];
    
    // Filter by 3-pillar thresholds
    let filtered = currentRecommendations.filter(item => {
      const audit = item.controlplane_audit;
      const perf = audit.performance_audit;
      if (audit.overall_trust_score < min_trust) return false;
      if (perf.price_staleness_days > max_staleness) return false;
      return true;
    });

    renderResults(filtered);
    renderMapPins(filtered);
  } catch (err) {
    console.error('Search error:', err);
    container.innerHTML = `<div class="text-rose-400 text-xs text-center py-8">Failed to connect to backend engine.</div>`;
  }
}

function renderResults(list) {
  const container = document.getElementById('recommendations-container');
  container.innerHTML = '';

  document.getElementById('results-count-badge').innerText = `${list.length} Governed Venues Found`;

  if (list.length === 0) {
    container.innerHTML = `
      <div class="py-12 text-center text-slate-400 space-y-2 bg-[#0F172A] border border-slate-700 rounded-xl p-5">
        <i data-lucide="search-x" class="w-6 h-6 mx-auto text-slate-500"></i>
        <h4 class="font-bold text-white text-xs">No Matching Verified Venues</h4>
        <p class="text-[11px] text-slate-400">Zero venues matched your exact search or geofence radius. ControlPlane prevented irrelevant results.</p>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
    return;
  }

  list.forEach((item, index) => {
    const v = item.venue;
    const audit = item.controlplane_audit;
    const perf = audit.performance_audit;
    const resp = audit.responsibility_audit;

    const gmapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(v.name + ' ' + v.area + ' Hyderabad')}`;

    let badgeClass = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
    let actionText = 'ALLOW';
    if (audit.policy_action === 'MODIFY') {
      badgeClass = 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      actionText = 'MODIFY';
    }

    let iconName = 'utensils';
    if (v.category.includes('Services') || v.category.includes('Gym')) iconName = 'dumbbell';
    else if (v.category.includes('Fashion') || v.category.includes('Retail')) iconName = 'shopping-bag';
    else if (v.category.includes('Entertainment')) iconName = 'gamepad-2';

    const card = document.createElement('div');
    card.id = `card-${v.id}`;
    card.className = 'venue-card p-3.5 space-y-2.5';
    card.onmouseenter = () => highlightMarker(v.id);
    card.onmouseleave = () => resetMarker(v.id);

    if (currentAuditViewMode === 'raw') {
      card.innerHTML = `
        <div class="space-y-1.5">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
              UNMONITORED RAW AI OUTPUT
            </span>
            <span class="text-xs font-mono font-bold text-amber-400">Rating: ${v.raw_rating} / 5.0</span>
          </div>
          <h4 class="text-xs font-bold text-white">${v.name}</h4>
          <p class="text-[11px] text-slate-400">${v.description}</p>
          <div class="p-2 rounded bg-rose-950/30 border border-rose-500/30 text-[11px] text-rose-300">
            Missing ControlPlane Verification: Stale prices (${perf.price_staleness_days}d) & unverified ratings trusted blindly.
          </div>
        </div>
      `;
    } else {
      card.innerHTML = `
        <div class="space-y-2">
          <!-- Top Row: Area Tag & Action Badge -->
          <div class="flex items-center justify-between gap-2">
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0F172A] text-slate-300 border border-slate-700 flex items-center space-x-1">
              <i data-lucide="${iconName}" class="w-3 h-3 text-indigo-400"></i>
              <span>${v.category} &bull; ${v.area}</span>
            </span>
            <div class="flex items-center space-x-1.5 font-mono text-[10px]">
              <span class="px-2 py-0.5 rounded font-bold border ${badgeClass}">${actionText}</span>
              <span class="text-emerald-300 font-bold bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">${audit.overall_trust_score}% Trust</span>
            </div>
          </div>

          <!-- Title & Description -->
          <div>
            <h4 class="text-xs font-bold text-white tracking-tight">${v.name}</h4>
            <p class="text-[11px] text-slate-400 mt-0.5 line-clamp-2">${v.description}</p>
          </div>

          <!-- Proof-of-Customer Dwell Time Stamp -->
          <div class="flex items-center space-x-1.5 px-2 py-1 rounded bg-[#0F172A] border border-slate-700/80 text-[10px] font-mono">
            <i data-lucide="award" class="w-3 h-3 text-amber-400"></i>
            <span class="text-amber-300">Proof-of-Customer: 28m In-Store Dwell Time Verified (0% Bot Risk)</span>
          </div>

          <!-- 3-Pillar Micro Metric Strip -->
          <div class="grid grid-cols-3 gap-1.5 bg-[#0F172A] p-1.5 rounded-lg border border-slate-700/80 text-center font-mono text-[10px]">
            <div>
              <span class="text-[9px] text-slate-400 block">FRESHNESS</span>
              <span class="font-bold ${perf.price_freshness_index > 50 ? 'text-indigo-400' : 'text-amber-400'}">${perf.price_staleness_days}d ago</span>
            </div>
            <div>
              <span class="text-[9px] text-slate-400 block">DISTANCE</span>
              <span class="font-bold text-white">${perf.actual_distance_km} km</span>
            </div>
            <div>
              <span class="text-[9px] text-slate-400 block">AUTH RATING</span>
              <span class="font-bold text-purple-400">${resp.authenticity_adjusted_rating} / 5.0</span>
            </div>
          </div>

          <!-- Disclaimers if any -->
          ${audit.disclaimers.length > 0 ? `
            <div class="p-1.5 rounded bg-amber-950/30 border border-amber-500/30 text-[10px] text-amber-300">
              ${audit.disclaimers.map(d => `<p>&bull; ${d}</p>`).join('')}
            </div>
          ` : ''}

          <!-- Bottom Action Buttons: Google Maps Photos & Rate/Verify -->
          <div class="grid grid-cols-2 gap-1.5 pt-0.5">
            <a href="${gmapsUrl}" target="_blank" rel="noopener" class="py-1.5 px-2 rounded-lg bg-[#0F172A] hover:bg-slate-800 border border-slate-700 text-slate-200 text-[11px] font-medium text-center flex items-center justify-center space-x-1 transition shadow-sm">
              <i data-lucide="map" class="w-3 h-3 text-indigo-400"></i>
              <span>Google Maps Photos &rarr;</span>
            </a>
            <button onclick="openReviewModal('${v.id}', '${v.name.replace(/'/g, "\'")}')" class="py-1.5 px-2 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-[11px] font-medium flex items-center justify-center space-x-1 transition">
              <i data-lucide="message-square-plus" class="w-3 h-3 text-indigo-400"></i>
              <span>Rate & Verify</span>
            </button>
          </div>
        </div>

        <button onclick="viewAuditTrace(${index})" class="w-full mt-1.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-400 text-[10px] font-mono flex items-center justify-center space-x-1">
          <i data-lucide="cpu" class="w-3 h-3 text-indigo-400"></i>
          <span>Inspect 3-Pillar Diagnostics</span>
        </button>
      `;
    }

    container.appendChild(card);
  });

  if (window.lucide) lucide.createIcons();
}

function renderMapPins(list) {
  if (!map) return;

  try {
    Object.values(venueMarkers).forEach(m => map.removeLayer(m));
    venueMarkers = {};

    list.slice(0, 50).forEach(item => {
      const v = item.venue;
      const audit = item.controlplane_audit;

      let pinClass = 'pin-allow';
      if (audit.policy_action === 'MODIFY') pinClass = 'pin-modify';
      else if (audit.policy_action === 'BLOCK') pinClass = 'pin-block';

      const icon = L.divIcon({
        className: `custom-pin ${pinClass}`,
        html: `<i data-lucide="shield" class="w-3.5 h-3.5"></i>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      const marker = L.marker([v.latitude, v.longitude], { icon })
        .addTo(map)
        .bindPopup(`
          <div class="p-2.5 space-y-1.5 min-w-[200px] text-xs">
            <div class="flex items-center justify-between">
              <span class="font-bold text-white text-xs">${v.name}</span>
              <span class="text-[10px] font-mono text-emerald-400 font-bold">${audit.overall_trust_score}%</span>
            </div>
            <p class="text-[10px] text-slate-400">${v.category} &bull; ${v.area}</p>
            <div class="pt-1 border-t border-slate-700 flex items-center justify-between text-[10px] font-mono">
              <span class="text-slate-300">Rs. ${Math.round(v.avg_cost_for_two)}</span>
              <span class="text-indigo-400 font-bold">${audit.policy_action}</span>
            </div>
          </div>
        `);

      marker.on('click', () => {
        const cardEl = document.getElementById(`card-${v.id}`);
        if (cardEl) {
          cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
          cardEl.classList.add('ring-2', 'ring-indigo-500');
          setTimeout(() => cardEl.classList.remove('ring-2', 'ring-indigo-500'), 2000);
        }
      });

      venueMarkers[v.id] = marker;
    });

    if (window.lucide) lucide.createIcons();
  } catch (e) {
    console.error('Error rendering map markers:', e);
  }
}

function highlightMarker(venueId) {
  const marker = venueMarkers[venueId];
  if (marker && map) {
    marker.openPopup();
    map.panTo(marker.getLatLng(), { animate: true, duration: 0.4 });
  }
}

function resetMarker(venueId) {
  const marker = venueMarkers[venueId];
  if (marker) {
    marker.closePopup();
  }
}

function openReviewModal(venueId, venueName) {
  const idEl = document.getElementById('modal-review-venue-id');
  const nameEl = document.getElementById('modal-review-venue-name');
  const statusEl = document.getElementById('review-submit-status');
  const modalEl = document.getElementById('review-modal');

  if (idEl) idEl.value = venueId;
  if (nameEl) nameEl.innerText = `Venue: ${venueName}`;
  if (statusEl) statusEl.classList.add('hidden');
  if (modalEl) modalEl.classList.remove('hidden');
  if (window.lucide) lucide.createIcons();
}

function presetVerifiedReview() {
  const revUser = document.getElementById('rev-username');
  const revRating = document.getElementById('rev-rating');
  const revProof = document.getElementById('rev-proof');
  const revText = document.getElementById('rev-text');

  if (revUser) revUser.value = 'Barath (IIT Hyderabad - Verified Visitor)';
  if (revRating) revRating.value = '5.0';
  if (revProof) revProof.value = 'dwell_time';
  if (revText) revText.value = 'Spent 35 minutes on-site. Exceptional service, clean modern facilities, and billing was completely transparent with 0 hidden fees.';
}

function closeReviewModal() {
  document.getElementById('review-modal').classList.add('hidden');
}

async function submitVerifiedReview(e) {
  e.preventDefault();
  const venue_id = document.getElementById('modal-review-venue-id').value;
  const user_name = document.getElementById('rev-username').value;
  const rating = parseFloat(document.getElementById('rev-rating').value);
  const proof_type = document.getElementById('rev-proof').value;
  const review_text = document.getElementById('rev-text').value;

  const statusDiv = document.getElementById('review-submit-status');
  statusDiv.classList.remove('hidden');
  statusDiv.className = 'p-2.5 rounded-lg text-xs font-mono bg-indigo-950/40 border border-indigo-500/30 text-indigo-300';
  statusDiv.innerText = 'Auditing review text with NLP template detector...';

  try {
    const res = await fetch('/api/reviews/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ venue_id, user_name, rating, proof_type, review_text })
    });
    const data = await res.json();
    if (data.success) {
      statusDiv.className = 'p-2.5 rounded-lg text-xs font-mono bg-emerald-950/40 border border-emerald-500/30 text-emerald-300';
      statusDiv.innerHTML = `
        Verified Customer Feedback Authenticated!<br>
        &bull; Proof Tier: ${data.proof_type.toUpperCase()}<br>
        &bull; Bot Match Risk: ${data.scripted_review_probability}%<br>
        &bull; Trust Weight: ${data.trust_weight_applied * 100}%<br>
        &bull; Updated Trust Score: <strong>${data.recalibrated_venue_trust_score}%</strong>
      `;
      setTimeout(() => {
        closeReviewModal();
        handleSearch();
      }, 2000);
    }
  } catch (err) {
    statusDiv.className = 'p-2.5 rounded-lg text-xs font-mono bg-rose-950/40 border border-rose-500/30 text-rose-300';
    statusDiv.innerText = 'Failed to submit review.';
  }
}

function viewAuditTrace(index) {
  const item = currentRecommendations[index];
  if (!item) return;

  const v = item.venue;
  const audit = item.controlplane_audit;
  const perf = audit.performance_audit;
  const resp = audit.responsibility_audit;
  const cost = audit.cost_audit;

  document.getElementById('modal-trace-venue-name').innerText = `Diagnostic Trace: ${v.name}`;
  
  const modalBody = document.getElementById('modal-audit-body');
  modalBody.innerHTML = `
    <div class="grid grid-cols-3 gap-2 p-2.5 rounded-lg bg-[#0F172A] border border-slate-700 text-center font-mono">
      <div>
        <span class="text-slate-400 block text-[9px]">RISK SCORE</span>
        <span class="text-xs font-bold text-rose-400">${audit.overall_risk_score}/100</span>
      </div>
      <div>
        <span class="text-slate-400 block text-[9px]">TRUST SCORE</span>
        <span class="text-xs font-bold text-emerald-400">${audit.overall_trust_score}/100</span>
      </div>
      <div>
        <span class="text-slate-400 block text-[9px]">POLICY ACTION</span>
        <span class="text-xs font-bold text-indigo-400">${audit.policy_action}</span>
      </div>
    </div>

    <div class="p-2.5 rounded-lg bg-[#0F172A] border border-slate-700 space-y-1">
      <span class="font-bold text-emerald-400 text-xs block font-mono">1. Performance Pillar (${perf.score}/100)</span>
      <p class="text-slate-300">&bull; Freshness: <strong>${perf.price_freshness_index}%</strong> (${perf.price_staleness_days}d ago)</p>
      <p class="text-slate-300">&bull; Distance: <strong>${perf.actual_distance_km} km</strong></p>
    </div>

    <div class="p-2.5 rounded-lg bg-[#0F172A] border border-slate-700 space-y-1">
      <span class="font-bold text-amber-400 text-xs block font-mono">2. Cost Pillar (${cost.score}/100)</span>
      <p class="text-slate-300">&bull; Token Consumption: <strong>${cost.total_tokens} tokens</strong></p>
      <p class="text-slate-300">&bull; Semantic Cache: <strong>${cost.cache_hit ? 'HIT (100% Saved)' : 'MISS'}</strong></p>
    </div>

    <div class="p-2.5 rounded-lg bg-[#0F172A] border border-slate-700 space-y-1">
      <span class="font-bold text-purple-400 text-xs block font-mono">3. Responsibility Pillar (${resp.score}/100)</span>
      <p class="text-slate-300">&bull; Bot Review Risk: <strong>${resp.scripted_review_probability}%</strong></p>
      <p class="text-slate-300">&bull; Calibrated Rating: <strong>${resp.authenticity_adjusted_rating} / 5.0</strong></p>
    </div>
  `;

  document.getElementById('audit-modal').classList.remove('hidden');
  if (window.lucide) lucide.createIcons();
}

function closeAuditModal() {
  document.getElementById('audit-modal').classList.add('hidden');
}

function openNeighborhoodModal() {
  document.getElementById('neighborhood-modal').classList.remove('hidden');
  if (window.lucide) lucide.createIcons();
}

function closeNeighborhoodModal() {
  document.getElementById('neighborhood-modal').classList.add('hidden');
}

async function handleCustomVenueAudit(e) {
  e.preventDefault();
  const name = document.getElementById('cust-name').value;
  const category = document.getElementById('cust-category').value;
  const avg_cost = parseFloat(document.getElementById('cust-price').value);
  const reviews_raw = document.getElementById('cust-reviews').value;
  const reviews = reviews_raw.split('\n').map(r => r.trim()).filter(r => r.length > 0);

  const outputDiv = document.getElementById('custom-audit-output');
  outputDiv.classList.remove('hidden');
  outputDiv.innerHTML = `<div class="text-slate-400 text-xs py-3 text-center">Auditing <strong>${name}</strong>...</div>`;

  try {
    const res = await fetch('/api/controlplane/audit-custom-venue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, category, avg_cost, menu_days_old: 8, rating: 4.8, reviews })
    });
    const data = await res.json();
    const audit = data.audit;

    outputDiv.innerHTML = `
      <div class="p-3 rounded-lg bg-[#0F172A] border border-slate-700 space-y-1.5 text-xs">
        <div class="flex items-center justify-between">
          <span class="font-bold text-white">${data.venue_name}</span>
          <span class="px-2 py-0.5 rounded text-[10px] font-bold ${audit.policy_action === 'ALLOW' ? 'text-emerald-400 bg-emerald-500/20' : 'text-amber-400 bg-amber-500/20'}">${audit.policy_action}</span>
        </div>
        <p class="text-slate-300">Trust Score: <strong>${audit.overall_trust_score}%</strong> | Risk: <strong>${audit.overall_risk_score}/100</strong></p>
        <p class="text-slate-400">Reasons: ${audit.reasons.join(', ')}</p>
      </div>
    `;
  } catch (err) {
    outputDiv.innerHTML = `<div class="text-rose-400 text-xs">Audit failed.</div>`;
  }
}

function openObservabilityModal() {
  document.getElementById('observability-modal').classList.remove('hidden');
  if (window.lucide) lucide.createIcons();
}

function closeObservabilityModal() {
  document.getElementById('observability-modal').classList.add('hidden');
}
