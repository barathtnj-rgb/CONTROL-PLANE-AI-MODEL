# Prototype Demo Video Script (3 Minutes)
**Accenture AI Innovation Challenge 2026 ? Round 2 Submission**  
**Team:** STRIVERS (*Barath.I & Sandeep ? IIT Hyderabad*)  
**Project:** ControlPlane.ai  

---

## ?? Video Recording Checklist:
* **Tool:** Loom / OBS / Windows Screen Recorder (`Win + Alt + R`).
* **Duration:** 2:30 to 3:00 minutes.
* **Target Screen:** Browser open at `http://localhost:8080`.

---

## ??? Step-by-Step Script:

### 0:00 ? 0:30 | The Hook & Problem Statement
* **Speaker:**
  > "Hello judges! We are Team STRIVERS from IIT Hyderabad, presenting **ControlPlane.ai** for the Accenture Innovation Challenge 2026.
  > Today, generative AI and autonomous recommenders make confident suggestions across dining, retail, and entertainment. However, they frequently mislead users with 7-month-old stale prices, fake bot-scripted review rings, and dangerous dietary cross-contaminations. 
  > Our solution is **ControlPlane.ai**?an inline, real-time governance middleware that audits AI recommendations before they reach the user."

---

### 0:30 ? 1:00 | The 3 Pillars Concept
* **Speaker:**
  > "ControlPlane evaluates every single AI candidate across three deterministic pillars:
  > 1. **? Performance Pillar:** Mathematically modeling price freshness decay with exponential curves and validating physical GPS coordinates.
  > 2. **?? Cost Pillar:** Tracking token consumption and leveraging semantic caching to cut external LLM costs by up to 70%.
  > 3. **??? Responsibility Pillar:** Running NLP N-Gram cluster algorithms to detect repetitive bot review rings and neutralizing commercial sponsor bias."

---

### 1:00 ? 2:00 | Live Prototype Walkthrough (Show Browser)
* **Action 1:** Click **"1. Food: Clean Pure Veg"** preset.
  > "Here is a clean recommendation. It passes all 3 pillars with a 94% trust score, so ControlPlane grants an **ALLOW** badge."
* **Action 2:** Click **"2. Retail: Fake 80% Discount Markup Scam"** preset.
  > "In retail, unmonitored AI promotes a warehouse claiming 80% off. ControlPlane detects inflated base MRPs and flags it with a **MODIFY** warning."
* **Action 3:** Click **"3. Food/Lounge: Scripted Review Ring"** preset.
  > "This lounge had an inflated 4.8? rating. ControlPlane's NLP engine detected that 83% of reviews share identical bot phrase templates, and automatically recalibrates the rating down to 3.3?."
* **Action 4:** Click **"Audit Any Business" Tab**.
  > "Users and judges can also type ANY real business name, address, and reviews from their own neighborhood to run the live 3-pillar audit on demand."

---

### 2:00 ? 2:30 | Observability & Business ROI
* **Action:** Click **Observability Tab**.
  > "ControlPlane provides live enterprise telemetry?tracking policy intervention breakdowns, sub-15ms latency budgets, and token savings from deduplication."

---

### 2:30 ? 3:00 | Conclusion & Impact
* **Speaker:**
  > "Today, platforms tell you what is popular. ControlPlane tells you what is right, verifiable, and safe before you act on it. Thank you!"

---

**Team STRIVERS** ? IIT Hyderabad
