# 1-Click Free Cloud Deployment Guide
**ControlPlane.ai** can be deployed online in 2 minutes using **Render.com** (Free tier, 24/7 HTTPS URL).

---

## ?? Steps to Deploy to Render.com:

1. **Push your code to GitHub:**
   * Create a new public repository on GitHub (e.g. `controlplane-ai`).
   * Push your local `controlplane-ai` folder to that repository.

2. **Go to Render:**
   * Visit [https://render.com](https://render.com) and sign in with GitHub (Free).

3. **Deploy Web Service:**
   * Click **"New +"** ? Select **"Web Service"**.
   * Choose your `controlplane-ai` repository.
   * Fill in these 3 fields:
     * **Name:** `controlplane-ai`
     * **Runtime:** `Python 3`
     * **Start Command:** `python server.py`
   * Select the **"Free"** instance tier.
   * Click **"Deploy Web Service"**.

4. **Your Live Public Link:**
   * In ~60 seconds, Render will provide your public URL:
     `https://controlplane-ai.onrender.com`
   * You can open this link from your phone, laptop, or share it directly with hackathon judges!
