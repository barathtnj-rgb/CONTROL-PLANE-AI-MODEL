# Build frontend files
import os

FRONTEND_DIR = 'C:/Users/kalav/.gemini/antigravity/scratch/controlplane-ai/frontend'
os.makedirs(FRONTEND_DIR, exist_ok=True)
